package com.example.myvibe;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;

public class SongAdapter extends RecyclerView.Adapter<SongAdapter.SongViewHolder> {
    private Context context;
    private List<Song> songs;
    private List<Song> songsFiltered;
    private OnSongClickListener listener;
    private DatabaseHelper databaseHelper;

    public interface OnSongClickListener {
        void onSongClick(int position);
        void onMoreClick(Song song, int position);
        void onFavoriteClick(Song song);
    }

    public SongAdapter(Context context, List<Song> songs, OnSongClickListener listener) {
        this.context = context;
        this.songs = songs;
        this.songsFiltered = new ArrayList<>(songs);
        this.listener = listener;
        this.databaseHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_song, parent, false);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SongViewHolder holder, int position) {
        Song song = songsFiltered.get(position);

        holder.songTitle.setText(song.getTitle());
        holder.artistName.setText(song.getArtist());
        holder.duration.setText(song.getFormattedDuration());

        // Check and update favorite status
        boolean isFavorite = databaseHelper.isFavorite(song.getId());
        updateFavoriteIcon(holder.btnFavorite, isFavorite);

        // Load album art
        Glide.with(context)
                .load(song.getAlbumArt())
                .placeholder(R.drawable.default_album_art)
                .error(R.drawable.default_album_art)
                .into(holder.albumArt);

        // Click listeners
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onSongClick(songs.indexOf(song));
        });

        holder.btnFavorite.setOnClickListener(v -> {
            if (listener != null) {
                listener.onFavoriteClick(song);
                boolean newStatus = databaseHelper.isFavorite(song.getId());
                updateFavoriteIcon(holder.btnFavorite, newStatus);
            }
        });

        holder.btnMore.setOnClickListener(v -> {
            if (listener != null) listener.onMoreClick(song, position);
        });
    }

    private void updateFavoriteIcon(ImageButton button, boolean isFavorite) {
        if (isFavorite) {
            button.setImageResource(R.drawable.ic_heart_filled);
        } else {
            button.setImageResource(R.drawable.ic_heart_outline);
        }
    }

    @Override
    public int getItemCount() {
        return songsFiltered.size();
    }

    public void filter(String query) {
        songsFiltered.clear();
        if (query.isEmpty()) {
            songsFiltered.addAll(songs);
        } else {
            String lowerQuery = query.toLowerCase();
            for (Song song : songs) {
                if (song.getTitle().toLowerCase().contains(lowerQuery) ||
                        song.getArtist().toLowerCase().contains(lowerQuery)) {
                    songsFiltered.add(song);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void updateSongs(List<Song> newSongs) {
        this.songs = newSongs;
        this.songsFiltered = new ArrayList<>(newSongs);
        notifyDataSetChanged();
    }

    static class SongViewHolder extends RecyclerView.ViewHolder {
        ImageView albumArt;
        TextView songTitle, artistName, duration;
        ImageButton btnMore, btnFavorite;

        public SongViewHolder(@NonNull View itemView) {
            super(itemView);
            albumArt = itemView.findViewById(R.id.albumArt);
            songTitle = itemView.findViewById(R.id.songTitle);
            artistName = itemView.findViewById(R.id.artistName);
            duration = itemView.findViewById(R.id.duration);
            btnMore = itemView.findViewById(R.id.btnMore);
            btnFavorite = itemView.findViewById(R.id.btnFavorite);
        }
    }
}