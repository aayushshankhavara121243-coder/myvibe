package com.example.myvibe;

import android.Manifest;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SongAdapter.OnSongClickListener {
    private static final int PERMISSION_REQUEST_CODE = 123;

    private RecyclerView recyclerView;
    private SongAdapter adapter;
    private List<Song> songList = new ArrayList<>();
    private EditText searchEditText;
    private TextView tvSongCount;
    private LinearLayout emptyState;
    private DatabaseHelper databaseHelper;

    private CardView miniPlayer;
    private ImageView miniAlbumArt;
    private TextView miniSongTitle, miniArtistName;
    private ImageButton miniPlayPauseBtn;

    private MusicService musicService;
    private boolean serviceBound = false;
    private Handler handler = new Handler();

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder) service;
            musicService = binder.getService();
            serviceBound = true;
            musicService.setSongList(songList);
            updateMiniPlayer();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        initializeViews();
        checkPermission();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewSongs);
        searchEditText = findViewById(R.id.searchEditText);
        tvSongCount = findViewById(R.id.tvSongCount);
        emptyState = findViewById(R.id.emptyState);

        miniPlayer = findViewById(R.id.miniPlayer);
        miniAlbumArt = findViewById(R.id.miniAlbumArt);
        miniSongTitle = findViewById(R.id.miniSongTitle);
        miniArtistName = findViewById(R.id.miniArtistName);
        miniPlayPauseBtn = findViewById(R.id.miniPlayPauseBtn);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SongAdapter(this, songList, this);
        recyclerView.setAdapter(adapter);

        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        miniPlayer.setOnClickListener(v -> openPlayerActivity());

        miniPlayPauseBtn.setOnClickListener(v -> {
            if (serviceBound && musicService != null) {
                if (musicService.isPlaying()) {
                    musicService.pauseSong();
                    miniPlayPauseBtn.setImageResource(R.drawable.ic_play);
                } else {
                    musicService.resumeSong();
                    miniPlayPauseBtn.setImageResource(R.drawable.ic_pause);
                }
            }
        });
    }

    private void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_AUDIO}, PERMISSION_REQUEST_CODE);
            } else {
                loadSongs();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
            } else {
                loadSongs();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadSongs();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    private void loadSongs() {
        songList.clear();
        ContentResolver contentResolver = getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String[] projection = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATA
        };

        Cursor cursor = contentResolver.query(uri, projection, selection, null,
                MediaStore.Audio.Media.TITLE + " ASC");

        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                String artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                String album = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM));
                long albumId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID));
                long duration = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));

                Uri albumArtUri = Uri.parse("content://media/external/audio/albumart");
                String albumArt = Uri.withAppendedPath(albumArtUri, String.valueOf(albumId)).toString();

                Song song = new Song(id, title, artist, album, albumArt, duration, path);
                songList.add(song);
            }
            cursor.close();
        }

        if (songList.isEmpty()) {
            emptyState.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            emptyState.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            adapter.updateSongs(songList);
            tvSongCount.setText(songList.size() + " Songs");

            Intent intent = new Intent(this, MusicService.class);
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
        }
    }

    @Override
    public void onSongClick(int position) {
        if (serviceBound && musicService != null) {
            musicService.setSongList(songList);
            musicService.playSong(position);
            miniPlayer.setVisibility(View.VISIBLE);
            updateMiniPlayer();
            openPlayerActivity();
        }
    }

    @Override
    public void onMoreClick(Song song, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(song.getTitle())
                .setItems(new String[]{"Play", "Song Info"}, (dialog, which) -> {
                    if (which == 0) {
                        onSongClick(position);
                    } else {
                        showSongInfo(song);
                    }
                })
                .show();
    }

    @Override
    public void onFavoriteClick(Song song) {
        if (databaseHelper.isFavorite(song.getId())) {
            databaseHelper.removeFromFavorites(song.getId());
            Toast.makeText(this, "💔 Removed from favorites", Toast.LENGTH_SHORT).show();
        } else {
            databaseHelper.addToFavorites(song.getId());
            Toast.makeText(this, "❤️ Added to favorites", Toast.LENGTH_SHORT).show();
        }
        adapter.notifyDataSetChanged();
    }

    private void showSongInfo(Song song) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Song Information")
                .setMessage("Title: " + song.getTitle() + "\n" +
                        "Artist: " + song.getArtist() + "\n" +
                        "Album: " + song.getAlbum() + "\n" +
                        "Duration: " + song.getFormattedDuration())
                .setPositiveButton("OK", null)
                .show();
    }

    private void updateMiniPlayer() {
        if (serviceBound && musicService != null) {
            Song currentSong = musicService.getCurrentSong();
            if (currentSong != null) {
                miniSongTitle.setText(currentSong.getTitle());
                miniArtistName.setText(currentSong.getArtist());

                Glide.with(this)
                        .load(currentSong.getAlbumArt())
                        .placeholder(R.drawable.default_album_art)
                        .error(R.drawable.default_album_art)
                        .into(miniAlbumArt);

                miniPlayPauseBtn.setImageResource(
                        musicService.isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);

                handler.postDelayed(this::updateMiniPlayer, 1000);
            }
        }
    }

    private void openPlayerActivity() {
        startActivity(new Intent(this, PlayerActivity.class));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
        handler.removeCallbacksAndMessages(null);
    }
}