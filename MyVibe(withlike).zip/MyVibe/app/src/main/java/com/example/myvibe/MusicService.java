package com.example.myvibe;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MusicService extends Service implements MediaPlayer.OnCompletionListener,
        MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener {

    private final IBinder binder = new MusicBinder();
    private MediaPlayer mediaPlayer;
    private List<Song> songs = new ArrayList<>();
    private int currentPosition = 0;
    private boolean isRepeat = false;
    private boolean isShuffle = false;

    public class MusicBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnCompletionListener(this);
        mediaPlayer.setOnPreparedListener(this);
        mediaPlayer.setOnErrorListener(this);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public void setSongList(List<Song> songList) {
        this.songs = new ArrayList<>(songList);
    }

    public void playSong(int position) {
        if (songs == null || songs.isEmpty() || position < 0 || position >= songs.size()) return;
        currentPosition = position;
        Song song = songs.get(position);
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(song.getPath());
            mediaPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        mp.start();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        if (isRepeat) {
            playSong(currentPosition);
        } else {
            playNext();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        mp.reset();
        return false;
    }

    public void playNext() {
        if (songs == null || songs.isEmpty()) return;
        if (isShuffle) {
            currentPosition = new Random().nextInt(songs.size());
        } else {
            currentPosition = (currentPosition + 1) % songs.size();
        }
        playSong(currentPosition);
    }

    public void playPrevious() {
        if (songs == null || songs.isEmpty()) return;
        if (isShuffle) {
            currentPosition = new Random().nextInt(songs.size());
        } else {
            currentPosition = (currentPosition - 1 + songs.size()) % songs.size();
        }
        playSong(currentPosition);
    }

    public void pauseSong() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    public void resumeSong() {
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    public boolean isPlaying() {
        return mediaPlayer != null && mediaPlayer.isPlaying();
    }

    public int getCurrentPosition() {
        return mediaPlayer != null ? mediaPlayer.getCurrentPosition() : 0;
    }

    public int getDuration() {
        return mediaPlayer != null ? mediaPlayer.getDuration() : 0;
    }

    public void seekTo(int position) {
        if (mediaPlayer != null) {
            mediaPlayer.seekTo(position);
        }
    }

    public Song getCurrentSong() {
        if (songs != null && !songs.isEmpty() && currentPosition >= 0 && currentPosition < songs.size()) {
            return songs.get(currentPosition);
        }
        return null;
    }

    public boolean isRepeat() { return isRepeat; }
    public void setRepeat(boolean repeat) { isRepeat = repeat; }
    public boolean isShuffle() { return isShuffle; }
    public void setShuffle(boolean shuffle) { isShuffle = shuffle; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}