package com.example.myvibe;

import java.io.Serializable;

public class Song implements Serializable {
    private long id;
    private String title;
    private String artist;
    private String album;
    private String albumArt;
    private long duration;
    private String path;
    private boolean isFavorite;

    public Song(long id, String title, String artist, String album, String albumArt, long duration, String path) {
        this.id = id;
        this.title = title;
        this.artist = artist != null && !artist.equals("<unknown>") ? artist : "Unknown Artist";
        this.album = album != null && !album.equals("<unknown>") ? album : "Unknown Album";
        this.albumArt = albumArt;
        this.duration = duration;
        this.path = path;
        this.isFavorite = false;
    }

    public long getId() { return id; }
    public String getTitle() { return title; }
    public String getArtist() { return artist; }
    public String getAlbum() { return album; }
    public String getAlbumArt() { return albumArt; }
    public long getDuration() { return duration; }
    public String getPath() { return path; }
    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }

    public String getFormattedDuration() {
        long seconds = (duration / 1000) % 60;
        long minutes = (duration / (1000 * 60)) % 60;
        long hours = (duration / (1000 * 60 * 60)) % 24;

        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
}