package com.example.myvibe;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class PlayerActivity extends AppCompatActivity {
    private ImageView albumArtPlayer, backgroundBlur;
    private TextView songTitlePlayer, artistNamePlayer, currentTime, totalTime;
    private SeekBar seekBar;
    private FloatingActionButton btnPlayPause;
    private ImageButton btnPrevious, btnNext, btnShuffle, btnRepeat, btnBack, btnFavoritePlayer;

    private MusicService musicService;
    private boolean serviceBound = false;
    private Handler handler = new Handler();
    private DatabaseHelper databaseHelper;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder) service;
            musicService = binder.getService();
            serviceBound = true;
            updateUI();
            updateSeekBar();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        databaseHelper = new DatabaseHelper(this);
        initializeViews();
        bindMusicService();
        setupListeners();
    }

    private void initializeViews() {
        albumArtPlayer = findViewById(R.id.albumArtPlayer);
        backgroundBlur = findViewById(R.id.backgroundBlur);
        songTitlePlayer = findViewById(R.id.songTitlePlayer);
        artistNamePlayer = findViewById(R.id.artistNamePlayer);
        currentTime = findViewById(R.id.currentTime);
        totalTime = findViewById(R.id.totalTime);
        seekBar = findViewById(R.id.seekBar);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        btnPrevious = findViewById(R.id.btnPrevious);
        btnNext = findViewById(R.id.btnNext);
        btnShuffle = findViewById(R.id.btnShuffle);
        btnRepeat = findViewById(R.id.btnRepeat);
        btnBack = findViewById(R.id.btnBack);
        btnFavoritePlayer = findViewById(R.id.btnFavoritePlayer);
    }

    private void bindMusicService() {
        Intent intent = new Intent(this, MusicService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnPlayPause.setOnClickListener(v -> {
            if (serviceBound && musicService != null) {
                if (musicService.isPlaying()) {
                    musicService.pauseSong();
                    btnPlayPause.setImageResource(R.drawable.ic_play);
                } else {
                    musicService.resumeSong();
                    btnPlayPause.setImageResource(R.drawable.ic_pause);
                }
            }
        });

        btnNext.setOnClickListener(v -> {
            if (serviceBound && musicService != null) {
                musicService.playNext();
                updateUI();
            }
        });

        btnPrevious.setOnClickListener(v -> {
            if (serviceBound && musicService != null) {
                musicService.playPrevious();
                updateUI();
            }
        });

        btnShuffle.setOnClickListener(v -> {
            if (serviceBound && musicService != null) {
                boolean shuffle = !musicService.isShuffle();
                musicService.setShuffle(shuffle);
                btnShuffle.setColorFilter(shuffle ?
                        getResources().getColor(R.color.colorAccent) :
                        getResources().getColor(R.color.textSecondary));
            }
        });

        btnRepeat.setOnClickListener(v -> {
            if (serviceBound && musicService != null) {
                boolean repeat = !musicService.isRepeat();
                musicService.setRepeat(repeat);
                btnRepeat.setColorFilter(repeat ?
                        getResources().getColor(R.color.colorAccent) :
                        getResources().getColor(R.color.textSecondary));
            }
        });

        btnFavoritePlayer.setOnClickListener(v -> {
            if (serviceBound && musicService != null) {
                Song currentSong = musicService.getCurrentSong();
                if (currentSong != null) {
                    toggleFavorite(currentSong);
                }
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && serviceBound && musicService != null) {
                    int newPosition = (progress * musicService.getDuration()) / 100;
                    musicService.seekTo(newPosition);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void updateUI() {
        if (serviceBound && musicService != null) {
            Song currentSong = musicService.getCurrentSong();
            if (currentSong != null) {
                songTitlePlayer.setText(currentSong.getTitle());
                songTitlePlayer.setSelected(true);
                artistNamePlayer.setText(currentSong.getArtist());
                totalTime.setText(currentSong.getFormattedDuration());

                Glide.with(this)
                        .load(currentSong.getAlbumArt())
                        .placeholder(R.drawable.default_album_art)
                        .error(R.drawable.default_album_art)
                        .into(albumArtPlayer);

                Glide.with(this)
                        .load(currentSong.getAlbumArt())
                        .placeholder(R.drawable.gradient_player)
                        .error(R.drawable.gradient_player)
                        .into(backgroundBlur);

                btnPlayPause.setImageResource(
                        musicService.isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);

                btnShuffle.setColorFilter(musicService.isShuffle() ?
                        getResources().getColor(R.color.colorAccent) :
                        getResources().getColor(R.color.textSecondary));

                btnRepeat.setColorFilter(musicService.isRepeat() ?
                        getResources().getColor(R.color.colorAccent) :
                        getResources().getColor(R.color.textSecondary));

                updateFavoriteButton(currentSong);
            }
        }
    }

    private void updateFavoriteButton(Song song) {
        if (song != null) {
            boolean isFavorite = databaseHelper.isFavorite(song.getId());
            if (isFavorite) {
                btnFavoritePlayer.setImageResource(R.drawable.ic_heart_filled);
            } else {
                btnFavoritePlayer.setImageResource(R.drawable.ic_heart_outline);
            }
        }
    }

    private void toggleFavorite(Song song) {
        if (databaseHelper.isFavorite(song.getId())) {
            databaseHelper.removeFromFavorites(song.getId());
            btnFavoritePlayer.setImageResource(R.drawable.ic_heart_outline);
            Toast.makeText(this, "💔 Removed from favorites", Toast.LENGTH_SHORT).show();
        } else {
            databaseHelper.addToFavorites(song.getId());
            btnFavoritePlayer.setImageResource(R.drawable.ic_heart_filled);
            Toast.makeText(this, "❤️ Added to favorites", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateSeekBar() {
        if (serviceBound && musicService != null) {
            int currentPosition = musicService.getCurrentPosition();
            int duration = musicService.getDuration();

            if (duration > 0) {
                int progress = (currentPosition * 100) / duration;
                seekBar.setProgress(progress);
                currentTime.setText(formatTime(currentPosition));
            }

            handler.postDelayed(this::updateSeekBar, 1000);
        }
    }

    private String formatTime(int milliseconds) {
        long seconds = (milliseconds / 1000) % 60;
        long minutes = (milliseconds / (1000 * 60)) % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (serviceBound) {
            updateUI();
        }
    }
}